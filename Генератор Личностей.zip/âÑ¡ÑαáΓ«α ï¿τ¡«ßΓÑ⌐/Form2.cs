﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Constructor;

namespace Генератор_Личностей
{
    public partial class Form2 : Form
    {
        static DirectoryInfo simple_path = new DirectoryInfo(@"C:\Users\Даниил\source\repos\Генератор Личностей\Шаблоны");

        FileInfo[] files = simple_path.GetFiles();//Путь файла для создания

        //static string sampler_information;//Имя шаблона

        static int first_value;
        static int last_value;

        public Form2()
        {
            InitializeComponent();


            foreach (FileInfo file in files)//Проверка первого выпадающего списка
            {
                //sampler_information = file.Name;
                comboBox1.Items.Add(file.Name.Replace(".bin", string.Empty));
            }

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Click += new EventHandler(button1_Click);//События при нажатии клавиш
            button2.Click += new EventHandler(button2_Click);
            button3.Click += new EventHandler(button3_Click);
            button4.Click += new EventHandler(button4_Click);

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tableLayoutPanel1.RowCount = Constructor.Constructor.mass_of_parametrs.Length;
            tableLayoutPanel1.RowStyles[0].SizeType = SizeType.Percent;
            tableLayoutPanel1.RowCount = 9;
            for (int i= 1; i< Constructor.Constructor.mass_of_parametrs.Length; ++i)
            {//Создать
                Label name = new Label();//Имя параметра
                ComboBox first_CB = new ComboBox();//Первое значение
                ComboBox last_CB = new ComboBox();//Второе значение

                tableLayoutPanel1.Controls.Add(name, 0, i);//Добавления значения
                tableLayoutPanel1.Controls.Add(first_CB, 1, i);
                tableLayoutPanel1.Controls.Add(last_CB, 2, i);

                name.Text = Constructor.Constructor.mass_of_parametrs[i].ToString();//Имя параметра
                foreach (var item in Constructor.Constructor.string_mass[i])
                {//Добавление значения в первый Combobox
                    first_CB.Items.Add(item);
                }
                foreach (var item in Constructor.Constructor.string_mass[i])
                {//Добавление значения в второй Combobox
                    last_CB.Items.Add(item);
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {//Сохранить

        }

        private void button3_Click(object sender, EventArgs e)
        {//Загрузить

        }

        private void button4_Click(object sender, EventArgs e)
        {//Вернутся назад

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {
        }
    }
}