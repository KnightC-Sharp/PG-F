﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Генератор_Личностей
{
    class Rewriter
    {
        string file_name;//Имя файла
       
        static string simple_path = (@"C:\Users\Даниил\source\repos\Генератор личностей (Фэнтези)\Шаблоны\");
        //Путь файла
        struct Persona//Структура для более простой организации данных
        {
            public string first_name;//Имя параметра
            public int first_m;//Первое значение
            public int last_m;//Второе значение
            public char point;//Точка для разделения данных
            public Persona(string fn, char p_1, int fm, int lm)//Для получения доступа к данным
            {
                first_name = fn;
                point = p_1;
                first_m = fm;
                last_m = lm;
            }
        }

        public void Create_sample()//Создание Шаблона
        {
            Console.WriteLine("Введите название создаваемого шаблона:");
            //Создание или перепись шаблона
            file_name = Convert.ToString(Console.ReadLine() + ".bin");//.bin нужен для поиска файла

            simple_path += file_name;//Задает имя файла и задает его имя при создании

            Persona[] persona = new Persona[9];
            for (int i = 0; i < 9; ++i)//Цикл принимает и переписывает значения, организовывая данные
            {

            }

            using (BinaryWriter writer = new BinaryWriter(File.Open(simple_path, FileMode.OpenOrCreate)))
            {
                for (int i = 0; i < 9; ++i)//Перепись данных в бинарный вид
                {

                }
                writer.Close();//Закрытие потока
            }
        }

        public void Read_sample()//Чтение шаблона
        {
            Console.WriteLine("Введите название искомого шаблона:");
            //здесь почти так-же как при написании, только программа получает данные из файла

            simple_path += file_name;//Указание пути к файлу

            if (File.Exists(simple_path))
            {//Если файл существует, открывает его
                using (BinaryReader read = new BinaryReader(File.Open(simple_path, FileMode.Open)))
                {//Читает файл 
                    for (int i = 0; i < 9; ++i)
                    {//Перечитывает файл
                    }
                    read.Close();//Закрытие чтения
                }
            }
        }
    }
}
