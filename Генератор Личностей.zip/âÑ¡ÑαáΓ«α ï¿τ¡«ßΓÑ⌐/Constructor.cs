﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Sampler_maker;
using Генератор_Личностей;

namespace Constructor
{

    public class Constructor
    {

        public static Random rnd = new Random();

        public static string[,] C_persona = new string[9, 2];

        public static string[] mass_of_parametrs = new string[]{"Рост", "Вес", "Телосложение",
            "Цвет кожи", "Цвет волос", "Цвет глаз",
             "Работа","Растительность на лице", "Голос"};//Основные параметры

        public static readonly string[][] string_mass = new string[9][] { 
            //1
            new string[] { "///" },
            //2
            new string[] { "///" },
        //3
        new string[] { "Толстый", "Сильный", "Худой" },
        //4

        new string[] { "Белая", "Бежевая", "Смуглая",
            "Черная", "Блеклая", "Красная", "Оранжевая" ,"Желтая",
            "Зеленая", "Голубая", "Синяя", "Фиолетовая"},
        //5
        new string[] { "Брюнет", "Рыжий", "Блондин", "Шатен", "Русый" },
        //6
        
        new string[] { "Красные", "Оранжевые", "Желтые",
            "Зеленые", "Голубые","Синие", "Фиолетовые"},
        //7
        new string[] {"Кузнец", "Плотник", "Фермер", "Ткачь",
            "Стражник", "Бандит", "", "Воин", "Попрошайка", "Торговец"},
        //8
        new string[] { "Усы", "Борода", "Нет" },
        //9
        new string[] { "высокий женский", "низкий женский",
            " высокий мужской", "низкий мужской", "не гендерный"},
        };

        public static void Generation_of_person()
        {
            C_persona[0, 0] = mass_of_parametrs[0];
            C_persona[0, 1] = Convert.ToString(rnd.Next(Sampler.pers[0].first_m, Sampler.pers[0].last_m));
            C_persona[1, 0] = mass_of_parametrs[1];
            C_persona[1, 1] = Convert.ToString(rnd.Next(Sampler.pers[1].first_m, Sampler.pers[1].last_m));
            for (int i = 2; i < 9; ++i)
            {
                C_persona[i, 0] = mass_of_parametrs[i];
                C_persona[i, 1] = string_mass[i][rnd.Next(rnd.Next(Sampler.pers[i].first_m, Sampler.pers[i].last_m))];
            }
        }
    }
}
