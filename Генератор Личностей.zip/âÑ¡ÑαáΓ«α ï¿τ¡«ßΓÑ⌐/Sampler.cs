﻿using System;
using Генератор_Личностей;
using System.IO;

namespace Sampler_maker//Получает данные из файла, переписывая их в понятный тип данных
{
    public class Sampler
    {
        static DirectoryInfo simple_path = new DirectoryInfo(@"C:\Users\Даниил\source\repos\Генератор Личностей\Шаблоны");
        static FileInfo[] files = simple_path.GetFiles();//
        public struct Persona//Структура для более простой организации данных
        {
            public string first_name;//Имя параметра
            public int first_m;//Первое значение
            public int last_m;//Второе значение
            public char point;//Точка для разделения данных
            public Persona(string fn, char p_1, int fm, int lm)//Для получения доступа к данным
            {
                first_name = fn;
                point = p_1;
                first_m = fm;
                last_m = lm;
            }
        }
        public static Persona[] pers = new Persona[9];

        static string combobox_information;

        public static void Take_sample(string c_i)
        {
            combobox_information = c_i+".bin";
            foreach (FileInfo file in files)
            {
                if (file.Name == combobox_information & file.Exists)
                {
                    using (BinaryReader read = new BinaryReader(File.OpenRead(@"C:\Users\Даниил\source\repos\Генератор Личностей\Шаблоны\" + file)))
                    {
                        for (int i = 0; i < 9; ++i)
                        {
                            pers[i].first_name = read.ReadString();
                            pers[i].first_m = read.ReadInt32();
                            pers[i].point = read.ReadChar();
                            pers[i].last_m = read.ReadInt32();
                        }
                    }
                    Constructor.Constructor.Generation_of_person();
                }

            }
        }
    }
}