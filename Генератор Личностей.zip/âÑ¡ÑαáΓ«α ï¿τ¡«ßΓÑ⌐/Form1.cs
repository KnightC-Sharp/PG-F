﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Constructor;
using Sampler_maker;

namespace Генератор_Личностей
{
    public partial class Form1 : Form
    {
        static DirectoryInfo simple_path = new DirectoryInfo(@"C:\Users\Даниил\source\repos\Генератор Личностей\Шаблоны");
        static DirectoryInfo S_L_path = new DirectoryInfo(@"C:\Users\Даниил\source\repos\Генератор Личностей\Сохранение");

        Form2 f2 = new Form2();

        FileInfo[] files = simple_path.GetFiles();//Путь файла для создания
        FileInfo[] saves = S_L_path.GetFiles();//Путь файла для создания

        static string sampler_information;//Имя шаблона
        string save_information;//Имя сохранения
        public Form1()
        {
            InitializeComponent();

            foreach (FileInfo file in files)//Проверка первого выпадающего списка
            {
                sampler_information = file.Name;
                comboBox1.Items.Add(file.Name.Replace(".bin", string.Empty));
            }
            foreach (FileInfo saves in saves)//Проверка второго выпадающего списка
            {
                save_information = saves.Name;
                comboBox1.Items.Add(saves.Name.Replace(".bin", string.Empty));
            }
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Click += new EventHandler(button1_Click);//События при нажатии клавиш
            button2.Click += new EventHandler(button2_Click);
            button3.Click += new EventHandler(button3_Click);
            button4.Click += new EventHandler(button4_Click);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            sampler_information = Convert.ToString(comboBox1.SelectedItem);
            Sampler.Take_sample(sampler_information);//Передает имя шаблона в другой скрипт
            //Добавлять .bin не нужно
            for (int i = 0; i < 9; ++i)
            {
                textBox2.Text += Environment.NewLine
                    + Convert.ToString(Constructor.Constructor.C_persona[i, 0])
                    + "-"
                    + Convert.ToString(Constructor.Constructor.C_persona[i, 1]);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {//

        }

        private void button3_Click(object sender, EventArgs e)
        {//

        }

        private void button4_Click(object sender, EventArgs e)
        {// Открыть редактор шаблонов
            f2.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}
